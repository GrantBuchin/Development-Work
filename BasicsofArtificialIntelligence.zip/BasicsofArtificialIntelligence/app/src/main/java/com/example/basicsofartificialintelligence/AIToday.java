package com.example.basicsofartificialintelligence;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AIToday extends AppCompatActivity {

    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aitoday);
        TextView aiToday = (TextView) findViewById(R.id.aiToday);
        aiToday.setMovementMethod(new ScrollingMovementMethod());

        mTextView = (TextView) findViewById(R.id.aiToday);


        Button nextButton = (Button)findViewById(R.id.nextButton);

        nextButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                startActivity(new Intent(AIToday.this, FutureAI.class));

            }
        });

        Button prevButton = (Button)findViewById(R.id.prevButton);

        prevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AIToday.this, MainActivity.class));
            }
        });

        Button highButton = (Button) findViewById(R.id.highButton);

        highButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doTask();
            }
        });
    }

    protected void doTask(){

        String textToHighlight = "AI";

        String replacedWith = "<font color='red'>" + textToHighlight + "</font>";

        String originalString = mTextView.getText().toString();

        String modifiedString = originalString.replaceAll(textToHighlight,replacedWith);

        mTextView.setText(Html.fromHtml(modifiedString));
    }

}