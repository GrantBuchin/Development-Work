package com.example.basicsofartificialintelligence;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FutureAI extends AppCompatActivity {

    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_future_ai);
        final TextView FutureAI = (TextView) findViewById(R.id.FutureAI);
        FutureAI.setMovementMethod(new ScrollingMovementMethod());


        mTextView = (TextView) findViewById(R.id.FutureAI);

        Button prevButton = (Button)findViewById(R.id.prevButton);

        prevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FutureAI.this, AIToday.class));
            }
        });

        Button highButton = (Button) findViewById(R.id.highButton);

        highButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doTask();
            }
        });
    }

    protected void doTask(){

        String textToHighlight = "AI";

        String replacedWith = "<font color='red'>" + textToHighlight + "</font>";

        String originalString = mTextView.getText().toString();

        String modifiedString = originalString.replaceAll(textToHighlight,replacedWith);

        mTextView.setText(Html.fromHtml(modifiedString));
    }

}