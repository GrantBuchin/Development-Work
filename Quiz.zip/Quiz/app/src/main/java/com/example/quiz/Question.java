package com.example.quiz;

public class Question {

    public String questions[] = {
            "When is the United States Navy's Birthday?",
            "What is the main programming language for video games?",
            "Where is Java used most?",
            "How many layers is the android architecture made up of?",
            "What is ANR?"
    };

    public String choices[][] = {
            {"October 13, 1775", "September 20, 1776", "August 5, 1774", "July 4, 1778"},
            {"PHP", "C++", "C#", "Java"},
            {"Android Applications", "Java Web Applications", "Social Applications", "Trading Applications"},
            {"Three", "Five", "Four", "Seven"},
            {"Application Not Required", "Application Not Reviewed", "Application Not Responding", "Android Not Responding"}
    };

    public String correctAnswer[] = {
            "October 13, 1775",
            "C++",
            "Android Applications",
            "Four",
            "Application Not Responding"
    };

    public String getQuestion(int a){
        String question = questions[a];
        return question;
    }

    public String getchoice1(int a){
        String choice = choices[a][0];

        return choice;
    }

    public String getchoice2(int a){
        String choice = choices[a][1];
        return choice;
    }

    public String getchoice3(int a){
        String choice = choices[a][2];
        return choice;
    }

    public String getchoice4(int a){
        String choice = choices[a][3];
        return choice;
    }

    public String getCorrectAnswer(int a){
        String answer = correctAnswer[a];
        return answer;
    }
}
