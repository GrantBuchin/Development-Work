package com.example.stopwatch;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    Chronometer chronometer;
    Button Start, Stop, Reset;
    long stopTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chronometer = (Chronometer)findViewById(R.id.chronometer);
        Start = (Button)findViewById(R.id.buttonStart);
        Stop = (Button)findViewById(R.id.buttonStop);
        Reset = (Button)findViewById(R.id.buttonReset);

        Start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chronometer.setBase(SystemClock.elapsedRealtime() + stopTime);
                chronometer.start();
                Start.setVisibility(View.GONE);
                Stop.setVisibility(View.VISIBLE);
            }
        });

        Stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopTime = chronometer.getBase() - SystemClock.elapsedRealtime();
                chronometer.stop();
                Start.setVisibility(View.VISIBLE);
                Stop.setVisibility(View.GONE);
            }
        });

        Reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chronometer.setBase(SystemClock.elapsedRealtime());
                stopTime = 0;
                chronometer.stop();
                Start.setVisibility(View.VISIBLE);
                Stop.setVisibility(View.GONE);
            }
        });

    }
}
